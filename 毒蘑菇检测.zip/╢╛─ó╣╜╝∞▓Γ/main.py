
from time import time
from maix import serial #导入库
ser = serial.Serial("/dev/ttyS1",115200) #设置端口
ser_str="0" #数据初始化
ser_str1 = "0"
class Mask:
    mud_path = "./model-99090.awnn.mud"
    labels = ['yd', 'wd']
    anchors = [3.47, 3.03, 6.06, 4.81, 4.06, 4.56, 5.06, 5.31, 5.16, 3.81]


    def __init__(self) -> None:
        from maix import nn
        self.model = nn.load(self.mud_path)
        from maix.nn import decoder
        self.decoder = decoder.Yolo2(len(self.labels) , self.anchors , net_in_size = (224, 224) ,net_out_size = (7,7))

    def __del__(self):
        del self.model
        del self.decoder

    def cal_fps(self ,start , end):
        one_second = 1
        one_flash = end - start
        fps = one_second / one_flash
        return  fps

    def draw_rectangle_with_title(self ,img, box, disp_str , fps ):
        img.draw_rectangle(box[0], box[1], box[0] + box[2], box[1] + box[3],color=(255, 0, 0), thickness=2)
        img.draw_string(box[0], box[1]+ box[3] ,disp_str, scale=2,color=(0, 0, 255), thickness=2)
        img.draw_string(0, 0 ,'FPS :'+str(fps), scale=2 ,color=(0, 0, 255), thickness=1)

    def process(self,input):
        t =  time()
        out = self.model.forward(input, quantize=1, layout = "hwc")
        boxes, probs = self.decoder.run(out, nms=0.5, threshold=0.6, img_size=(224,224))
        global ser_str
        global ser_str1
        for i, box in enumerate(boxes):
            class_id = probs[i][0]
            prob = probs[i][1][class_id]
            disp_str = "{}:{:.2f}%".format(self.labels[class_id], prob*100)
            fps = self.cal_fps(t, time())
            self.draw_rectangle_with_title(input, box, disp_str, fps)            
            ser_str=self.labels[class_id]
            if ser_str != ser_str1:
                ser.write(ser_str.encode('utf-8'))
                ser_str1 = ser_str

def main():
    from maix import display, camera
    app = Mask()
    camera.config((224,224))
    while True:
        img = camera.capture()
        app.process(img)
        display.show(img)
main()